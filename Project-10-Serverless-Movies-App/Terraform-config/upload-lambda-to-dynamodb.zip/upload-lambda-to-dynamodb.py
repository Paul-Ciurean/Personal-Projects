import boto3
import csv
import os

# Initialize the S3 and DynamoDB clients
s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
table_name = os.environ['TABLE_NAME'].strip()
table = dynamodb.Table(table_name)

# Initialize SNS client
sns_client = boto3.client('sns')

# Get the SNS Topic ARN from environment variables
SNS_TOPIC_ARN = os.environ['SNS_TOPIC_ARN'].strip()

def delete_existing_items():
    """Scan and delete all items from the DynamoDB table."""
    scan = table.scan()
    with table.batch_writer() as batch:
        for each in scan['Items']:
            batch.delete_item(
                Key={
                    'movies': each['movies']  # Replace 'movies' with your table's primary key
                }
            )
    print('All existing items deleted.')

def lambda_handler(event, context):
    try:
        # Step 1: Delete existing data from the DynamoDB table
        delete_existing_items()
        
        # Step 2: Process and upload new data from the CSV file
        total_records = 0
        for record in event['Records']:
            bucket = record['s3']['bucket']['name']
            key = record['s3']['object']['key']
            
            response = s3_client.get_object(Bucket=bucket, Key=key)
            lines = response['Body'].read().decode('utf-8-sig').split('\n')
            
            csv_reader = csv.reader(lines)
            headers = next(csv_reader)  # Read the first line as headers
            
            with table.batch_writer() as batch:
                for line in csv_reader:
                    if line:  # Skip empty lines
                        item = {headers[i]: line[i] for i in range(len(headers))}
                        print(item)
                        batch.put_item(Item=item)
                        total_records += 1
        
        # Step 3: After processing and updating DynamoDB, send an SNS notification
        sns_client.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=f'Successfully processed and uploaded {total_records} records to DynamoDB.',
            Subject='Movie Update Completed'
        )
        print('Notification sent successfully.')

        return {
            'statusCode': 200,
            'body': f'Successfully processed {total_records} records.'
        }
    
    except Exception as e:
        # Send notification in case of an error
        sns_client.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=f'Error occurred while processing records: {str(e)}',
            Subject='Movie Update Failed'
        )
        print(f'Error sending notification: {str(e)}')
        return {
            'statusCode': 500,
            'body': f'Error processing records: {str(e)}'
        }
