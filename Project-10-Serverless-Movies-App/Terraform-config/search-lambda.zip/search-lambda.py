import json
import boto3
from boto3.dynamodb.conditions import Key
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')

def decimal_to_int_or_float(obj):
    """Helper function to convert Decimal to int or float."""
    if isinstance(obj, Decimal):
        return float(obj)  # Convert Decimal to float (or int() if preferred)
    elif isinstance(obj, dict):
        return {k: decimal_to_int_or_float(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [decimal_to_int_or_float(i) for i in obj]
    else:
        return obj

def lambda_handler(event, context):
    # Log the entire event object to see what is being received
    print("Received event: " + json.dumps(event, indent=2))

    table = dynamodb.Table('Movies')
    
    # Extract movie from queryStringParameters
    movie_name = event.get('queryStringParameters', {}).get('movieName')
    
    if not movie_name:
        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,GET'
            },
            'body': json.dumps({'error': 'movieName parameter is required'})
        }
    
    try:
        response = table.query(
            KeyConditionExpression=Key('movies').eq(movie_name)
        )
        
        items = response.get('Items', [])
        
        if not items:
            return {
                'statusCode': 404,
                'headers': {
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,GET'
                },
                'body': json.dumps({'error': 'Movie not found'})
            }
        
        # Convert items to JSON-serializable format
        items = decimal_to_int_or_float(items)
        
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,GET'
            },
            'body': json.dumps(items)
        }
    
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,GET'
            },
            'body': json.dumps({'error': str(e)})
        }
