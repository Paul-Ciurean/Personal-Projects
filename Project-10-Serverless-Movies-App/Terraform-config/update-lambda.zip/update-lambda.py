import json
import boto3

dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    table = dynamodb.Table('Movies')
    
    try:
        # Scan the table and retrieve only the 'movies' primary key
        response = table.scan(
            ProjectionExpression='movies'
        )
        
        # Log the response for debugging
        print("DynamoDB Scan Response:", response)
        
        # Extract the 'movies' primary keys from the response
        primary_keys = [item.get('movies', 'N/A') for item in response['Items']]
        
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,GET'
            },
            'body': json.dumps(primary_keys)
        }
    
    except Exception as e:
        print("Error:", str(e))
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,GET'
            },
            'body': json.dumps({'error': str(e)})
        }
